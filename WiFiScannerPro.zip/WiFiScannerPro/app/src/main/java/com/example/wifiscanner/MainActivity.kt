package com.example.wifiscanner

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.InetAddress
import java.net.Inet4Address
import java.net.URL
import java.net.HttpURLConnection

private val Bg = Color(0xFF08111F)
private val Panel = Color(0xFF111F32)
private val Accent = Color(0xFF35C6F4)
private val Muted = Color(0xFF9CB0C8)

data class NearbyNetwork(val ssid: String, val level: Int, val frequency: Int, val secured: Boolean)
data class DeviceInfo(val ip: String, val mac: String, val name: String, val method: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { WifiScannerApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WifiScannerApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val wifi = remember { context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager }
    var networks by remember { mutableStateOf<List<NearbyNetwork>>(emptyList()) }
    var devices by remember { mutableStateOf<List<DeviceInfo>>(emptyList()) }
    var status by remember { mutableStateOf("امنح الصلاحيات ثم ابدأ الفحص") }
    var scanning by remember { mutableStateOf(false) }
    var gateway by remember { mutableStateOf("غير معروف") }
    var currentSsid by remember { mutableStateOf("غير متصل") }
    var routerInfo by remember { mutableStateOf("قراءة أجهزة راوتر Vodafone تعتمد على موديل الراوتر وواجهة الإدارة.") }

    val requiredPermissions = remember {
        buildList {
            add(Manifest.permission.ACCESS_FINE_LOCATION)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.NEARBY_WIFI_DEVICES)
        }.toTypedArray()
    }
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result.values.all { it }) status = "تم منح الصلاحيات. اضغط فحص الشبكات."
        else status = "يلزم السماح بصلاحيات Wi‑Fi والموقع لفحص الشبكات القريبة."
    }

    fun hasPermissions(): Boolean = requiredPermissions.all {
        ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
    }

    fun refreshWifi() {
        if (!hasPermissions()) {
            permissionLauncher.launch(requiredPermissions)
            return
        }
        try {
            @Suppress("DEPRECATION")
            val started = wifi.startScan()
            @Suppress("DEPRECATION")
            val results = wifi.scanResults
            networks = results.map {
                val caps = it.capabilities ?: ""
                NearbyNetwork(it.SSID.ifBlank { "(شبكة مخفية)" }, it.level, it.frequency,
                    caps.contains("WPA") || caps.contains("WEP") || caps.contains("SAE"))
            }.distinctBy { it.ssid }.sortedByDescending { it.level }
            @Suppress("DEPRECATION")
            val info = wifi.connectionInfo
            currentSsid = info?.ssid?.trim('"')?.takeIf { it.isNotBlank() } ?: "غير متصل"
            val dhcp = wifi.dhcpInfo
            val gw = dhcp.gateway
            gateway = if (gw == 0) "غير معروف" else
                listOf(0, 8, 16, 24).joinToString(".") { ((gw shr it) and 0xff).toString() }
            status = if (started) "تم تحديث نتائج المسح" else "عرض آخر نتائج متاحة من النظام"
        } catch (e: SecurityException) {
            status = "لا توجد صلاحية كافية. راجع أذونات التطبيق."
        } catch (e: Exception) {
            status = "تعذر قراءة الشبكات: ${e.localizedMessage ?: "خطأ غير معروف"}"
        }
    }

    fun scanDevices() {
        if (gateway == "غير معروف") {
            status = "اتصل بشبكة Wi‑Fi أولاً ثم حدّث معلومات الشبكة."
            return
        }
        scanning = true
        status = "جارٍ فحص الأجهزة على شبكتك..."
        scope.launch {
            val found = withContext(Dispatchers.IO) {
                val list = mutableListOf<DeviceInfo>()
                // ARP cache is a best-effort source. Android may restrict visibility.
                try {
                    val lines = java.io.File("/proc/net/arp").readLines().drop(1)
                    for (line in lines) {
                        val p = line.trim().split(Regex("\\s+"))
                        if (p.size >= 4 && p[3].matches(Regex("(?i)([0-9a-f]{2}:){5}[0-9a-f]{2}")) && p[3] != "00:00:00:00:00:00") {
                            list.add(DeviceInfo(p[0], p[3].uppercase(), "جهاز على الشبكة", "ذاكرة ARP"))
                        }
                    }
                } catch (_: Exception) {}
                // Limited reachability sweep of the local /24 subnet.
                val prefix = gateway.substringBeforeLast(".") + "."
                for (i in 1..254) {
                    val ip = prefix + i
                    try {
                        val addr = InetAddress.getByName(ip)
                        if (addr.isReachable(180) && list.none { it.ip == ip }) {
                            list.add(DeviceInfo(ip, "غير متاح", addr.hostName ?: "جهاز نشط", "فحص اتصال"))
                        }
                    } catch (_: Exception) {}
                }
                list.distinctBy { it.ip }.sortedBy { it.ip }
            }
            devices = found
            scanning = false
            status = "انتهى الفحص. النتائج تقديرية وقد لا تظهر الأجهزة التي تمنع الاستجابة."
        }
    }

    fun openRouter() {
        try {
            val url = "http://$gateway"
            context.startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)))
        } catch (_: Exception) {
            status = "تعذر فتح صفحة الراوتر."
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent, background = Bg, surface = Panel,
            onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Scaffold(containerColor = Bg, topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("WiFi Scanner Pro", fontWeight = FontWeight.Bold, color = Color.White)
                        Text("إدارة وفحص الشبكة المحلية", fontSize = 11.sp, color = Muted)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Bg),
                actions = {
                    IconButton(onClick = { refreshWifi() }) {
                        Icon(Icons.Default.Refresh, contentDescription = "تحديث", tint = Accent)
                    }
                }
            )
        }) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 28.dp)
            ) {
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                        Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("حالة الاتصال", color = Muted, fontSize = 13.sp)
                            Text(currentSsid, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Column { Text("عنوان الراوتر", color = Muted, fontSize = 11.sp); Text(gateway, color = Accent) }
                                Column(horizontalAlignment = Alignment.End) { Text("الأجهزة المكتشفة", color = Muted, fontSize = 11.sp); Text("${devices.size}", color = Accent, fontSize = 22.sp, fontWeight = FontWeight.Bold) }
                            }
                        }
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = { refreshWifi() }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) {
                            Text("فحص الشبكات")
                        }
                        OutlinedButton(onClick = { scanDevices() }, modifier = Modifier.weight(1f), enabled = !scanning, shape = RoundedCornerShape(14.dp)) {
                            if (scanning) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                            else Icon(Icons.Default.Devices, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp)); Text("فحص الأجهزة")
                        }
                    }
                }
                item { Text(status, color = Muted, fontSize = 12.sp) }
                item { SectionTitle("الشبكات القريبة", "Wi‑Fi") }
                if (networks.isEmpty()) item { EmptyPanel("لا توجد نتائج بعد. اضغط فحص الشبكات.") }
                items(networks) { net ->
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
                        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Security, contentDescription = null, tint = Accent)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(net.ssid, color = Color.White, fontWeight = FontWeight.SemiBold)
                                Text("${net.frequency} MHz • ${if (net.secured) "محمية" else "مفتوحة"}", color = Muted, fontSize = 11.sp)
                            }
                            Text("${net.level} dBm", color = Accent, fontSize = 12.sp)
                        }
                    }
                }
                item { SectionTitle("الأجهزة المتصلة / المكتشفة", "LAN") }
                if (devices.isEmpty()) item { EmptyPanel("لم يتم اكتشاف أجهزة بعد. النتائج تعتمد على استجابة الأجهزة وقيود Android.") }
                items(devices) { device ->
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
                        Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Devices, contentDescription = null, tint = Accent)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(device.name, color = Color.White, fontWeight = FontWeight.Medium)
                                Text("${device.ip}  •  ${device.mac}", color = Muted, fontSize = 11.sp)
                                Text(device.method, color = Accent, fontSize = 10.sp)
                            }
                        }
                    }
                }
                item { SectionTitle("راوتر Vodafone", "ROUTER") }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Router, contentDescription = null, tint = Accent)
                                Spacer(Modifier.width(8.dp))
                                Text("لوحة إدارة الراوتر", color = Color.White, fontWeight = FontWeight.Bold)
                            }
                            Text("بوابة الراوتر: $gateway", color = Muted, fontSize = 12.sp)
                            Text(routerInfo, color = Muted, fontSize = 12.sp)
                            Button(onClick = { openRouter() }, modifier = Modifier.fillMaxWidth()) {
                                Text("فتح صفحة راوتر Vodafone")
                            }
                            Text("سجّل الدخول بنفسك إلى لوحة الراوتر، ثم افتح قائمة الأجهزة المتصلة. لا يرسل التطبيق كلمة المرور إلى أي خادم.", color = Muted, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(title: String, tag: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Text(tag, color = Accent, fontSize = 10.sp)
    }
}

@Composable
private fun EmptyPanel(message: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
        Text(message, Modifier.fillMaxWidth().padding(16.dp), color = Muted, fontSize = 12.sp)
    }
}
